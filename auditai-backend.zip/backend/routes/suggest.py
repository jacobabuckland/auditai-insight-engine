from fastapi import APIRouter
router = APIRouter()

@router.post('/suggest')
async def suggest():
    return {'message': 'suggest mock'}