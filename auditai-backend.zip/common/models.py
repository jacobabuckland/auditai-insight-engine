from pydantic import BaseModel
class Dummy(BaseModel): pass